import { ArrowRight } from "lucide-react"
import Link from "next/link"

export default function Home() {
  const toolCategories = [
    {
      title: "Measurement Conversions",
      tools: [
        { name: "Weight / Mass", path: "/weight", emoji: "⚖️" },
        { name: "Temperature", path: "/temperature", emoji: "🌡️" },
        { name: "Length / Distance", path: "/length", emoji: "📏" },
        { name: "Volume", path: "/volume", emoji: "🧪" },
        { name: "Time", path: "/time", emoji: "🕒" },
        { name: "Digital Storage", path: "/storage", emoji: "💾" },
        { name: "Energy / Power", path: "/energy", emoji: "⚡" },
        { name: "Speed", path: "/speed", emoji: "🚗" },
      ],
    },
    {
      title: "Calculators & Utilities",
      tools: [
        { name: "Currency Converter", path: "/currency", emoji: "💰" },
        { name: "Timestamp Tool", path: "/timestamp", emoji: "📅" },
        { name: "Text Tools", path: "/text", emoji: "📝" },
        { name: "Age Calculator", path: "/age", emoji: "🎂" },
        { name: "Loan / EMI Calculator", path: "/loan", emoji: "🏦" },
        { name: "Random Generators", path: "/random", emoji: "🎲" },
        { name: "Countdown Timer", path: "/timer", emoji: "⏱️" },
      ],
    },
  ]

  return (
    <div className="space-y-12">
      <section className="text-center py-12">
        <h1 className="text-4xl font-bold mb-4">ConvertHub</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Your all-in-one toolkit for conversions, calculations, and everyday utilities
        </p>
      </section>

      <section className="space-y-8">
        {toolCategories.map((category, index) => (
          <div key={index} className="space-y-4">
            <h2 className="text-2xl font-semibold">{category.title}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {category.tools.map((tool, toolIndex) => (
                <Link
                  key={toolIndex}
                  href={tool.path}
                  className="flex items-center p-4 border rounded-lg hover:shadow-md transition-shadow group"
                >
                  <span className="text-2xl mr-3">{tool.emoji}</span>
                  <span className="font-medium">{tool.name}</span>
                  <ArrowRight className="ml-auto h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Link>
              ))}
            </div>
          </div>
        ))}
      </section>
    </div>
  )
}

